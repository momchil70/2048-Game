#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;
constexpr int MAX_SIZE = 10;

bool isThereFreeSpaces(const int matrix[][MAX_SIZE], int size) {
	int countZeros = 0;
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			if (matrix[i][j] == 0) countZeros++;
		}
	}
	if (countZeros == 0) return false;
	return true;
}

void copyMatrix(const int source[][MAX_SIZE], int dest[][MAX_SIZE], int size) {
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			dest[i][j] = source[i][j];
		}
	}
}

bool compareMatrix(const int source[][MAX_SIZE], const int dest[][MAX_SIZE], int size) {
	bool areEqual = true;
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			if (source[i][j] != dest[i][j]) areEqual = false;
		}
	}
	return areEqual;
}

int getRandomNumber() {
	int number = rand() % 2;
	if (number == 0) return 2;
	if (number == 1) return 4;
}

void initialize(int matrix[][MAX_SIZE], int n) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			matrix[i][j] = 0;
		}
	}
}

void printMatrix(const int matrix[][MAX_SIZE], int n, int score) {
	cout << "Your score is: " << score << endl;
	cout << endl;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cout << setw(5) << matrix[i][j];
		}
		cout << endl;
	}
}

void changeMatrix(int matrix[][MAX_SIZE], int n, int newNumber) {
	int x = 0, y = 0;
	while (true) {
		x = rand() % n;
		y = rand() % n;
		if (matrix[x][y] == 0) {
			matrix[x][y] = newNumber;
			break;
		}
	}
}

bool isTherePossibleMoves(int matrix[][MAX_SIZE], int n) {
	bool flag = false;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n - 1; j++) {
			if (matrix[i][j] == matrix[i][j + 1]) {
				flag = true;
			}
		}
	}
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n; j++) {
			if (matrix[i][j] == matrix[i + 1][j]) {
				flag = true;
			}
		}
	}
	return flag;
}

void moveMatrix(int matrix[][MAX_SIZE], int n, char c, bool& shouldGetNewNumber) {
	switch (c) {
	case 'w': {
		int countZeroes = 0;
		for (int j = 0; j < n; j++) {
			for (int i = 0; i < n; i++) {
				if (matrix[i][j] == 0) countZeroes++;
				if (matrix[i][j] != 0 and countZeroes != 0) {
					matrix[i - countZeroes][j] = matrix[i][j];
					matrix[i][j] = 0;
				}
			}
			countZeroes = 0;
		}
		for (int j = 0; j < n; j++) {
			for (int i = 0; i < n - 1; i++) {
				if (matrix[i][j] == matrix[i + 1][j] and matrix[i][j] != 0) {
					matrix[i][j] *= 2;
					matrix[i + 1][j] = 0;
				}
			}
		}
		for (int j = 0; j < n; j++) {
			for (int i = 0; i < n; i++) {
				if (matrix[i][j] == 0) countZeroes++;
				if (matrix[i][j] != 0 and countZeroes != 0) {
					matrix[i - countZeroes][j] = matrix[i][j];
					matrix[i][j] = 0;
				}
			}
			countZeroes = 0;
		}
		break;
	}
	case 's': {
		int countZeroes = 0;
		for (int j = n - 1; j >= 0; j--) {
			for (int i = n - 1; i >= 0; i--) {
				if (matrix[i][j] == 0) countZeroes++;
				if (matrix[i][j] != 0 and countZeroes != 0) {
					matrix[i + countZeroes][j] = matrix[i][j];
					matrix[i][j] = 0;
				}
			}
			countZeroes = 0;
		}
		for (int j = n - 1; j >= 0; j--) {
			for (int i = n - 1; i > 0; i--) {
				if (matrix[i][j] == matrix[i - 1][j] and matrix[i][j] != 0) {
					matrix[i][j] *= 2;
					matrix[i - 1][j] = 0;
				}
			}
		}
		for (int j = n - 1; j >= 0; j--) {
			for (int i = n - 1; i >= 0; i--) {
				if (matrix[i][j] == 0) countZeroes++;
				if (matrix[i][j] != 0 and countZeroes != 0) {
					matrix[i + countZeroes][j] = matrix[i][j];
					matrix[i][j] = 0;
				}
			}
			countZeroes = 0;
		}
		break;
	}
	case 'a': {
		int countZeroes = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (matrix[i][j] == 0) countZeroes++;
				if (matrix[i][j] != 0 and countZeroes != 0) {
					matrix[i][j - countZeroes] = matrix[i][j];
					matrix[i][j] = 0;
				}
			}
			countZeroes = 0;
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n - 1; j++) {
				if (matrix[i][j] == matrix[i][j + 1] and matrix[i][j] != 0) {
					matrix[i][j] *= 2;
					matrix[i][j + 1] = 0;
				}
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (matrix[i][j] == 0) countZeroes++;
				if (matrix[i][j] != 0 and countZeroes != 0) {
					matrix[i][j - countZeroes] = matrix[i][j];
					matrix[i][j] = 0;
				}
			}
			countZeroes = 0;
		}
		break;
	}
	case 'd': {
		int countZeroes = 0;
		for (int i = n - 1; i >= 0; i--) {
			for (int j = n - 1; j >= 0; j--) {
				if (matrix[i][j] == 0) countZeroes++;
				if (matrix[i][j] != 0 and countZeroes != 0) {
					matrix[i][j + countZeroes] = matrix[i][j];
					matrix[i][j] = 0;
				}
			}
			countZeroes = 0;
		}
		for (int i = n - 1; i >= 0; i--) {
			for (int j = n - 1; j > 0; j--) {
				if (matrix[i][j] == matrix[i][j - 1] and matrix[i][j] != 0) {
					matrix[i][j] *= 2;
					matrix[i][j - 1] = 0;
				}
			}
		}
		for (int i = n - 1; i >= 0; i--) {
			for (int j = n - 1; j >= 0; j--) {
				if (matrix[i][j] == 0) countZeroes++;
				if (matrix[i][j] != 0 and countZeroes != 0) {
					matrix[i][j + countZeroes] = matrix[i][j];
					matrix[i][j] = 0;
				}
			}
			countZeroes = 0;
		}
		break;
	}
	default:
		cout << "invalid input. try again!" << endl;
		shouldGetNewNumber = false;
	}
}

void playGame() {
	srand(time(0));
	int matrix[MAX_SIZE][MAX_SIZE];
	int n = 0, score = 0;
	char move;
	string name;
	cout << "Enter your nickname: " << endl;
	cin >> name;
	system("cls");
	cout << name << ", enter playboard size(4-10): " << endl;
	cin >> n;

	while (n < 4 or n>10) {
		cout << "invalid input. the size must be between 4 and 10! enter again: " << endl;
		cin >> n;
	}

	system("cls");
	initialize(matrix, n);
	int newNumber = getRandomNumber();
	score += newNumber;
	changeMatrix(matrix, n, newNumber);
	printMatrix(matrix, n, score);
	int copyOfMatrix[MAX_SIZE][MAX_SIZE];

	while (isTherePossibleMoves(matrix, n) or isThereFreeSpaces(matrix, n)) {
		bool shouldGetNewNumber = true;
		cout << "enter direction: " << endl;
		cin >> move;
		system("cls");
		//�������
		copyMatrix(matrix, copyOfMatrix, n);
		moveMatrix(matrix, n, move, shouldGetNewNumber);
		if (shouldGetNewNumber == false or compareMatrix(matrix, copyOfMatrix, n)) {
			printMatrix(matrix, n, score);
			continue;
		}
		//����� ���� ���������
		newNumber = getRandomNumber();
		score += newNumber;
		changeMatrix(matrix, n, newNumber);
		printMatrix(matrix, n, score);
	}
	cout << "The game has ended! Your score is " << score << endl;
}

int main() {
	playGame();
	return 0;
}