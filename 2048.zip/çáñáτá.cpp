/**
*
* Solution to course project # 4
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2023/2024
*
* @author Momchil Yanakiev
* @idnumber 0MI0600347
* @compiler VC
*
* solution file
*
*/

#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
constexpr int MAX_SIZE = 10;
constexpr int LEADERBOARD_PLACES = 5;

bool isThereFreeSpaces(const int matrix[][MAX_SIZE], int size) {
	int countZeros = 0;
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			if (matrix[i][j] == 0) countZeros++;
		}
	}
	if (countZeros == 0) return false;
	return true;
}

void copyMatrix(const int source[][MAX_SIZE], int dest[][MAX_SIZE], int size) {
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			dest[i][j] = source[i][j];
		}
	}
}

bool compareMatrix(const int source[][MAX_SIZE], const int dest[][MAX_SIZE], int size) {
	bool areEqual = true;
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			if (source[i][j] != dest[i][j]) areEqual = false;
		}
	}
	return areEqual;
}

int getRandomNumber() {
	int number = rand() % 2;
	if (number == 0) return 2;
	if (number == 1) return 4;
}

void initialize(int matrix[][MAX_SIZE], int n) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			matrix[i][j] = 0;
		}
	}
}

void printMatrix(const int matrix[][MAX_SIZE], int n, int score) {
	cout << "Your score is: " << score << endl;
	cout << endl;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cout << setw(5) << matrix[i][j];
		}
		cout << endl;
	}
}

void changeMatrix(int matrix[][MAX_SIZE], int n, int newNumber) {
	int x = 0, y = 0;
	while (true) {
		x = rand() % n;
		y = rand() % n;
		if (matrix[x][y] == 0) {
			matrix[x][y] = newNumber;
			break;
		}
	}
}

bool isTherePossibleMoves(int matrix[][MAX_SIZE], int n) {
	bool flag = false;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n - 1; j++) {
			if (matrix[i][j] == matrix[i][j + 1]) {
				flag = true;
			}
		}
	}
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n; j++) {
			if (matrix[i][j] == matrix[i + 1][j]) {
				flag = true;
			}
		}
	}
	return flag;
}

void dragUp(int matrix[][MAX_SIZE], int n, int countZeroes) {
	for (int j = 0; j < n; j++) {
		for (int i = 0; i < n; i++) {
			if (matrix[i][j] == 0) countZeroes++;
			if (matrix[i][j] != 0 and countZeroes != 0) {
				matrix[i - countZeroes][j] = matrix[i][j];
				matrix[i][j] = 0;
			}
		}
		countZeroes = 0;
	}
}

void dragDown(int matrix[][MAX_SIZE], int n, int countZeroes) {
	for (int j = n - 1; j >= 0; j--) {
		for (int i = n - 1; i >= 0; i--) {
			if (matrix[i][j] == 0) countZeroes++;
			if (matrix[i][j] != 0 and countZeroes != 0) {
				matrix[i + countZeroes][j] = matrix[i][j];
				matrix[i][j] = 0;
			}
		}
		countZeroes = 0;
	}
}

void dragLeft(int matrix[][MAX_SIZE], int n, int countZeroes) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (matrix[i][j] == 0) countZeroes++;
			if (matrix[i][j] != 0 and countZeroes != 0) {
				matrix[i][j - countZeroes] = matrix[i][j];
				matrix[i][j] = 0;
			}
		}
		countZeroes = 0;
	}
}

void dragRight(int matrix[][MAX_SIZE], int n, int countZeroes) {
	for (int i = n - 1; i >= 0; i--) {
		for (int j = n - 1; j >= 0; j--) {
			if (matrix[i][j] == 0) countZeroes++;
			if (matrix[i][j] != 0 and countZeroes != 0) {
				matrix[i][j + countZeroes] = matrix[i][j];
				matrix[i][j] = 0;
			}
		}
		countZeroes = 0;
	}
}

void mergeNumbersUpAndLeft(int matrix[][MAX_SIZE], int n, int iStep, int jStep) {
	for (int j = 0; j < n; j++) {
		for (int i = 0; i < n; i++) {
			if (i + iStep >= n || j + jStep >= n) {
				continue;
			}
			if (matrix[i][j] == matrix[i + iStep][j + jStep] and matrix[i][j] != 0) {
				matrix[i][j] *= 2;
				matrix[i + iStep][j + jStep] = 0;
			}
		}
	}
}

void mergeNumbersDownAndRight(int matrix[][MAX_SIZE], int n, int iStep, int jStep) {
	for (int j = n - 1; j >= 0; j--) {
		for (int i = n - 1; i >= 0; i--) {
			if (i + iStep < 0 || j + jStep < 0) {
				continue;
			}
			if (matrix[i][j] == matrix[i + iStep][j + jStep] and matrix[i][j] != 0) {
				matrix[i][j] *= 2;
				matrix[i + iStep][j + jStep] = 0;
			}
		}
	}
}

void moveMatrix(int matrix[][MAX_SIZE], int n, char c, bool& shouldGetNewNumber) {
	int countZeroes = 0;
	switch (c) {
	case 'w': {
		dragUp(matrix, n, countZeroes);
		mergeNumbersUpAndLeft(matrix, n, 1, 0);
		dragUp(matrix, n, countZeroes);
		break;
	}
	case 's': {
		dragDown(matrix, n, countZeroes);
		mergeNumbersDownAndRight(matrix, n, -1, 0);
		dragDown(matrix, n, countZeroes);
		break;
	}
	case 'a': {
		dragLeft(matrix, n, countZeroes);
		mergeNumbersUpAndLeft(matrix, n, 0, 1);
		dragLeft(matrix, n, countZeroes);
		break;
	}
	case 'd': {
		dragRight(matrix, n, countZeroes);
		mergeNumbersDownAndRight(matrix, n, 0, -1);
		dragRight(matrix, n, countZeroes);
		break;
	}
	default:
		cout << "invalid input. try again!" << endl;
		shouldGetNewNumber = false;
	}
}

void outputRecords(const string nicknames[], const int scores[]) {
	for (int i = 0; i < LEADERBOARD_PLACES; i++) {
		cout << i + 1 << ")" << nicknames[i] << "-" << scores[i] << endl;
	}
}

void getBacktoMenu() {
	char back;
	while (true) {
		cout << "Enter the letter 'b' to go back to the menu!" << endl;
		cin >> back;
		if (back == 'b' || back == 'B') {
			break;
		}
	}
}

void getValues(fstream& Leaderboard, string* nicknames, int* scores) {
	if (Leaderboard.is_open()) {
		for (int i = 0; i < LEADERBOARD_PLACES; i++) {
			Leaderboard >> nicknames[i];
			Leaderboard >> scores[i];
		}
	}
	else {
		cout << "Could not open file" << endl;
	}
}


void generateArrays(string* nicknames, int* scores, int n) {
	fstream Leaderboard;
	switch (n) {
	case 4: {
		Leaderboard.open("Leaderboard4.txt", ios::in);
		getValues(Leaderboard, nicknames, scores);
		break;
	};
	case 5: {
		Leaderboard.open("Leaderboard5.txt", ios::in);
		getValues(Leaderboard, nicknames, scores);
		break;
	};
	case 6: {
		Leaderboard.open("Leaderboard6.txt", ios::in);
		getValues(Leaderboard, nicknames, scores);
		break;
	};
	case 7: {
		Leaderboard.open("Leaderboard7.txt", ios::in);
		getValues(Leaderboard, nicknames, scores);
		break;
	};
	case 8: {
		Leaderboard.open("Leaderboard8.txt", ios::in);
		getValues(Leaderboard, nicknames, scores);
		break;
	};
	case 9: {
		Leaderboard.open("Leaderboard9.txt", ios::in);
		getValues(Leaderboard, nicknames, scores);
		break;
	};
	case 10: {
		Leaderboard.open("Leaderboard10.txt", ios::in);
		getValues(Leaderboard, nicknames, scores);
		break;
	};
	}
	Leaderboard.close();
}

void showLeaderboards() {
	string nicknames[LEADERBOARD_PLACES];
	for (int i = 0; i < LEADERBOARD_PLACES; i++) {
		nicknames[i] = "Empty";
	}
	int scores[LEADERBOARD_PLACES] = { 0 };
	int dimension = 0;
	while (true) {
		cout << "Enter the dimension whose leaderboard you want to see (4-10): ";
		cin >> dimension;
		if (dimension >= 4 and dimension <= 10) {
			system("cls");
			break;
		}
		system("cls");
		cout << "Please put valid dimension!" << endl;
	}
	generateArrays(nicknames, scores, dimension);
	outputRecords(nicknames, scores);
	getBacktoMenu();
}

void clearFile(int n) {
	switch (n) {
	case 4: {
		ofstream file("Leaderboard4.txt");
		file << "";
		break;
	};
	case 5: {
		ofstream file("Leaderboard5.txt");
		file << "";
		break;
	};
	case 6: {
		ofstream file("Leaderboard6.txt");
		file << "";
		break;
	};
	case 7: {
		ofstream file("Leaderboard7.txt");
		file << "";
		break;
	};
	case 8: {
		ofstream file("Leaderboard8.txt");
		file << "";
		break;
	};
	case 9: {
		ofstream file("Leaderboard9.txt");
		file << "";
		break;
	};
	case 10: {
		ofstream file("Leaderboard10.txt");
		file << "";
		break;
	};
	}
}

void openFileForWriting(fstream& Leaderboard, int n) {
	switch (n) {
	case 4:
		Leaderboard.open("Leaderboard4.txt", ios::out);
		break;
	case 5:
		Leaderboard.open("Leaderboard5.txt", ios::out);
		break;
	case 6:
		Leaderboard.open("Leaderboard6.txt", ios::out);
		break;
	case 7:
		Leaderboard.open("Leaderboard7.txt", ios::out);
		break;
	case 8:
		Leaderboard.open("Leaderboard8.txt", ios::out);
		break;
	case 9:
		Leaderboard.open("Leaderboard9.txt", ios::out);
		break;
	case 10:
		Leaderboard.open("Leaderboard10.txt", ios::out);
		break;
	}
}

void checkForBeatingTheRecord(string* nicknames, int* scores, string name, int score, int n) {
	fstream Leaderboard;
	for (int i = 0; i < LEADERBOARD_PLACES; i++) {
		if (score > scores[i]) {
			for (int j = LEADERBOARD_PLACES - 1; j > i; j--) {
				scores[j] = scores[j - 1];
				nicknames[j] = nicknames[j - 1];
			}
			scores[i] = score;
			nicknames[i] = name;

			cout << "You are now in the " << i + 1 << " place in the leaderboard. Congratulations!" << endl;
			clearFile(n);
			openFileForWriting(Leaderboard, n);
			for (int j = 0; j < LEADERBOARD_PLACES; j++) {
				Leaderboard << nicknames[j] << " " << scores[j] << endl;
			}
			break;
		}
	}
	Leaderboard.close();
}

void playGame(int matrix[][MAX_SIZE], char move, int n, int& score) {
	system("cls");
	initialize(matrix, n);
	int newNumber = getRandomNumber();
	score += newNumber;
	changeMatrix(matrix, n, newNumber);
	printMatrix(matrix, n, score);
	int copyOfMatrix[MAX_SIZE][MAX_SIZE];
	while (isTherePossibleMoves(matrix, n) or isThereFreeSpaces(matrix, n)) {
		bool shouldGetNewNumber = true;
		cout << "enter direction: " << endl;
		cin >> move;
		system("cls");
		//moving the matrix
		copyMatrix(matrix, copyOfMatrix, n);
		moveMatrix(matrix, n, move, shouldGetNewNumber);
		if (shouldGetNewNumber == false or compareMatrix(matrix, copyOfMatrix, n)) {
			printMatrix(matrix, n, score);
			continue;
		}
		//generating a number after the movement
		newNumber = getRandomNumber();
		score += newNumber;
		changeMatrix(matrix, n, newNumber);
		printMatrix(matrix, n, score);
	}
	cout << "The game has ended! Your score is " << score << "." << endl;
}

void gameSettings() {
	srand(time(0));
	int scores[LEADERBOARD_PLACES] = { 0 };
	string nicknames[LEADERBOARD_PLACES];
	for (int i = 0; i < LEADERBOARD_PLACES; i++) {
		nicknames[i] = "Empty";
	}
	int matrix[MAX_SIZE][MAX_SIZE];
	int n = 0, score = 0;
	char move = ' ';
	string name;
	cout << "Enter your nickname: " << endl;
	cin >> name;
	system("cls");
	cout << name << ", enter playboard size(4-10): " << endl;
	cin >> n;
	while (n < 4 or n>10) {
		cout << "invalid input. the size must be between 4 and 10! enter again: " << endl;
		cin >> n;
	}
	//generating the nicknames and scores arrays
	generateArrays(nicknames, scores, n);
	//play the actual game
	playGame(matrix, move, n, score);
	checkForBeatingTheRecord(nicknames, scores, name, score, n);
	getBacktoMenu();
}

void openMenu() {
	char decision = ' ';
	while (decision != 'q') {
		system("cls");
		cout << "You have 3 options:" << endl;
		cout << "-play game (p)" << endl;
		cout << "-show leaderboards (l)" << endl;
		cout << "-quit (q)" << endl;
		cout << "Enter your choice: ";
		cin >> decision;
		switch (decision) {
		case 'p':
			system("cls");
			gameSettings();
			break;
		case 'l':
			system("cls");
			showLeaderboards();
		case 'q':
			system("cls");
			cout << "Thanks dor the game! Goodbye!" << endl;
			break;
		default:
			cout << "Invalid input. Try again: ";
		}
	}
}

int main() {
	openMenu();
	return 0;
}